# GameSeagull

Get it on my [repo](https://donato-fiore.github.io/repo)

If you would like to support me, consider donating [here](http://paypal.me/donatofiore)!

# Building & Installation
```SHELL
git clone https://github.com/donato-fiore/GameSeagull.git
cd GameSeagull
./build_release.sh
```

# Changelog
## [2.1](https://github.com/donato-fiore/GameSeagull/releases/tag/2.1) - 2024-02-01
### Updates:
- Fixed some icons not showing on < iOS 16
- Added:
    - Always 50ft Target
    - Auto Cup Pong Button
    - Darts Aimbot

## [2.0](https://github.com/donato-fiore/GameSeagull/releases/tag/2.0) - 2024-01-28
### Updates:
- **Dropped iOS 13 Support**
- Rootless and rootful support
- Rebuilt preferences
- Improve backend functionality
- Added "Disable Timer" hack

## [1.6](https://github.com/donato-fiore/GameSeagull/releases/download/1.6/com.fiore.gameseagull_1.6_iphoneos-arm.deb) - 2021-11-19
### Changed
- How the tweak uses prefs (hopefully this works)
### Added
- Always move 8 ball cue
- Archery target always set to 50ft away
## [1.5.1](https://github.com/donato-fiore/GameSeagull/releases/download/1.5.1/com.donato.gameseagull_1.5.1_iphoneos-arm.deb) - 2021-08-23
### Changed
- How the tweak loads the preferences, which was causing some users to not be able to use the tweak (Thank you [Chr1s](https://github.com/Chr1sDev))
## [1.5](https://github.com/donato-fiore/GameSeagull/releases/download/1.5/com.donato.gameseagull_1.5_iphoneos-arm.deb) - 2021-08-21
### Added
- Infinite 8 ball lines
- RGB 8 ball lines
## [1.4](https://github.com/donato-fiore/GameSeagull/releases/download/1.4/com.donato.gameseagull_1.4_iphoneos-arm.deb) - 2021-08-18
### Added
- See enemy ships in sea battle
- Auto anagrams word solver
## [1.3.1](https://github.com/donato-fiore/GameSeagull/releases/download/1.3.1/com.donato.gameseagull_1.3.1_iphoneos-arm.deb) - 2021-08-17
### Added
- Disabling hard mode in all 8 ball games
### Changed
- The code for win spoofing
## [1.3](https://github.com/donato-fiore/GameSeagull/releases/download/1.3/com.donato.gameseagull_1.3_iphoneos-arm.deb) - 2021-08-15
### Added
- Icon to the settings preference
- Word Solver for Word Hunt
### Changed
- The button used in anagrams
- The code for unscrambling words in anagrams
## [1.2](https://github.com/donato-fiore/GameSeagull/releases/download/1.2/com.donato.gameseagull_1.2_iphoneos-arm.deb) - 2021-08-07
### Added
- Win Spoofer
- Anagrams Word Unscrambler
- One shot Cup Pong win
## [1.1](https://github.com/donato-fiore/GameSeagull/releases/download/1.1/com.donato.gameseagull_1.1_iphoneos-arm.deb) - 2021-08-01
### Added
- Auto Hole in One for Mini Golf
### Changed
- Starting to use [Cephei](https://hbang.github.io/libcephei/) for a better preference bundle
## 1.0 - 2021-05-23
Initial Release
### Added
- Archery No Wind
- Always showing trajectory line in 8 ball **NOT EXTENDED LINES**
- Darts One Shot Win
- Tanks No Wind
